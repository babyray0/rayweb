## Simple site: Easy websites with GitHub pages

[Github Pages](https://pages.github.com) provide a simple way to make a
website using Markdown and git.

This is a minimal tutorial to get started.

View the thing [here](https://kbroman.org/simple_site).

---

To the extent possible under law,
[Karl Broman](https://github.com/kbroman)
has waived all copyright and related or neighboring rights to
&ldquo;[simple site](https://github.com/kbroman/simple_site)&rdquo;.
This work is published from the United States.
<br/>
[![CC0](https://i.creativecommons.org/p/zero/1.0/88x31.png)](https://creativecommons.org/publicdomain/zero/1.0/)
